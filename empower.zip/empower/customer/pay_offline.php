<center><!-- center Starts -->

<h1> payment Using Method  </h1>

<p class="text-muted" >

If you have any questions, please feel free to <a href="../contact.php" >contact us,</a> our customer service center is working for you 

</p>

</center><!-- center Ends -->

<hr>


<div class="table-responsive" ><!-- table-responsive Starts -->

<table class="table table-bordered table-hover table-striped" ><!-- table table-bordered table-hover table-striped Starts -->

<thead><!-- thead Starts -->

<tr>

<th> recipient's name </th>

<th> Bank name </th>

<th> address </th>

</tr>

</thead><!-- thead Ends -->

<tbody><!-- tbody Starts -->

<tr>

<td>  Name:Rofifah Ayu Widiastuti  Code:0342 	 </td>

<td> Bank Name: Bca  </td>

<td> Alamat : Jalan Pelita IV No. 92, RT 08 RW 06, Kelurahan Sei Timur, Kecamatan Medan Timur, Medan, Sumatera Utara, 79831.
</td>


</tr>

</tbody><!-- tbody Ends -->


</table><!-- table table-bordered table-hover table-striped Ends -->

</div><!-- table-responsive Ends -->
